#ifndef DEF_CBVERTEX
#define DEF_CBVERTEX
#include "CBMatrix.h"

class CBVertex{
	public :
		float x, y, z;
		CBVertex();
		CBVertex(const CBVertex&);
		CBVertex(float, float, float);
		~CBVertex();
		void Set(float, float, float);
		void Normalize();
		void Normalize(const CBVertex&);
		float Length() const;
		void Inverse();
		float Sproduct(CBVertex)const;
		CBVertex& operator+(const CBVertex&);
		CBVertex& operator-(const CBVertex&);
		CBVertex& operator*( CBVertex&);
		CBVertex& operator*(const float);
		CBVertex& operator*(const CBMatrix&);
		CBVertex& operator/(const float);
		CBVertex& operator=(const CBVertex&);
		CBVertex& operator+=(const CBVertex&);
		CBVertex& operator-=(const CBVertex&);
		CBVertex& operator*=(const CBVertex&);
		CBVertex& operator*=(const float);
		CBVertex& operator*=(const CBMatrix&);
		CBVertex& operator/=(const float);
		bool operator==(const CBVertex&);
		void Print();
		void Printlength();
};

#endif DEF_CBVERTEX