#include "CBTriangle.h"
#include <stdio.h>
// > TRIANGLES

CBTriangle::CBTriangle(const CBVertex& v0, const CBVertex& v1, const CBVertex& v2, rgb_color c){
	Dot[0]=CBVertex(v0);
	Dot[1]=CBVertex(v1);
	Dot[2]=CBVertex(v2);
	norm.Normalize((Dot[2]-Dot[0])*(Dot[1]-Dot[0]));
	col = c;
	/*
	Edge[0] = CBVertex(.0,.0,.0);
	Edge[1] = CBVertex(.0,.0,.0);
	Edge[2] = CBVertex(.0,.0,.0);
	*/
}
/*
void CBTriangle::Set(const CBVertex& e0, const CBVertex& e1, const CBVertex& e2, rgb_color c){
	Edge[0].Normalize(e0);
	Edge[1].Normalize(e1);
	Edge[2].Normalize(e2);
	col =c ;
}
*/
void CBTriangle::Roteer(CBMatrix& m){

	Dot[0]=Dot[0]*m;
	Dot[1]=Dot[1]*m;
	Dot[2]=Dot[2]*m;
	/**
	Edge[0]=Edge[0]*m;
	Edge[1]=Edge[1]*m;
	Edge[2]=Edge[2]*m;
	**/
	norm=norm*m;
}
void CBTriangle::Move(CBVertex& v){
	Dot[0]+=v;
	Dot[1]+=v;
	Dot[2]+=v;
}

float CBTriangle::MaxPar(){
	if (Dot[0].y > Dot[1].y)
		if (Dot[0].y > Dot[2].y)
			return Dot[0].y; 
		else
			return Dot[2].y;
	else
		if (Dot[1].y > Dot[2].y)
			return Dot[1].y; 
		else
			return Dot[2].y;
}
float CBTriangle::MinPar(){
	if (Dot[0].y < Dot[1].y)
		if (Dot[0].y < Dot[2].y)
			return Dot[0].y; 
		else
			return Dot[2].y;
	else
		if (Dot[1].y < Dot[2].y)
			return Dot[1].y; 
		else
			return Dot[2].y;
}

bool CBTriangle::IsPoint(CBVertex& v){
	if (Dot[0]==v)
		return 1;
	else if (Dot[1]==v)
		return 1;
	else if (Dot[2]==v)
		return 1;
	else
		return 0;
}