/*

		implementation of rotation matrices only ...

*/

#ifndef DEF_MATRICES
#define DEF_MATRICES


class CBMatrix{
	public :
	
		float Matrix[3][3];
		
		CBMatrix ();			//makes I3
		void Reset();
		
		void MakeRotateX(float);		// init
		void MakeRotateY(float);	
		void MakeRotateZ(float);
		
		CBMatrix& MakeMeRotateX(float);
		CBMatrix& MakeMeRotateY(float);
		CBMatrix& MakeMeRotateZ(float);
		
		CBMatrix& operator+(const CBMatrix&);
		CBMatrix& operator-(const CBMatrix&);
		CBMatrix& operator*(const CBMatrix&);
		CBMatrix& operator*(const float);
		CBMatrix& operator/(const CBMatrix&);
		
		CBMatrix& operator+=(const float);
		CBMatrix& operator-=(const float);
		CBMatrix& operator*=(const CBMatrix&);
		CBMatrix& operator*=(const float);
		CBMatrix& operator/=(const float);
		
				
		
		void Transponeer();
		void Invert();
		
		CBMatrix& Getransponeerde();
		CBMatrix& Inverted();
		void Print();

};

#endif DEF_MATRICES
