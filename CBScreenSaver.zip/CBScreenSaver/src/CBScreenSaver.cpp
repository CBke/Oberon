#include "CBScreenSaver.h"
#include <StringView.h>
#include <stdlib.h>
#include <View.h>
#include <Screen.h>
#include <stdio.h>
#include <time.h>
#include <Roster.h>
#include "CBParser.h"


#include <WindowScreen.h>
// MAIN INSTANTIATION FUNCTION
extern "C" _EXPORT BScreenSaver *instantiate_screen_saver(BMessage *message, image_id image)
{
	return new CBScreenSaver(message, image);
}

class EMailStringView : public BStringView
{
public :
	EMailStringView ( BRect frame_, const char* string_ ) :
	BStringView ( frame_, NULL, string_ )
	{
		this->SetHighColor ( 0, 0, 255 ) ;
	}

	virtual void MouseDown ( BPoint point_ )
	{
		char* argv [] =
		{
			"mailto:LuckyStar@LinuxMail.org",
			"-subject",
			"CBScreenSaver v 0.0.2",
			
		} ;

		BStringView::MouseDown ( point_ ) ;

		BRoster ().Launch ( "text/x-email", 5, argv ) ;
	}
} ;

CBScreenSaver::CBScreenSaver(BMessage *msg, image_id image)
 : BScreenSaver(msg, image),detail_slider ( NULL )
{

	b=0;
	if ( msg->FindInt8 ( "detail", (int8*)&this->detail ) != B_OK ) this->detail = 5;
	
}
CBScreenSaver::~CBScreenSaver(){}

void CBScreenSaver::StartConfig(BView *view)
{
	BStringView *tview = new BStringView(BRect(10, 10, 150, 35), B_EMPTY_STRING, "CB ScreenSaver");
	tview->SetFont(be_bold_font);
	tview->SetFontSize(15);
	view->AddChild(tview);
	view->AddChild(new BStringView(BRect(150, 15, 300, 30), B_EMPTY_STRING, "   Ver. 0.0.2 "));
	
	this->detail_slider = new BSlider ( BRect(20,50,200,100), "detail", "detail", NULL, 1.0, 10.0 ) ;
	
	view->AddChild(new BStringView(BRect(20, 100, 250, 120), B_EMPTY_STRING, "This slider does not (yet) work perfectly..."));
	view->AddChild (new EMailStringView(BRect(20,120,200,160), "LuckyStar@LinuxMail.Org" ) );
	

	this->detail_slider->SetHashMarks ( B_HASH_MARKS_BOTTOM ) ;
	this->detail_slider->SetHashMarkCount ( 11 ) ;
	this->detail_slider->SetLimitLabels ( "low", "high" ) ;
	this->detail_slider->SetValue ( detail ) ;
	view->AddChild ( this->detail_slider ) ;


}

void CBScreenSaver::StopConfig ()
{
	if ( this->detail_slider != NULL )
	{
		this->detail = this->detail_slider->Value ();
		this->detail_slider = NULL ;
	}


}

status_t CBScreenSaver::StartSaver(BView * view, bool preview)
{
	i=Draw_Flat;
	if (preview)
		return B_ERROR;
	return B_OK;
	
}
status_t CBScreenSaver::SaveState ( BMessage* state_ ) const
{
	
	state_->AddInt8 ( "detail", this->detail ) ;
	return B_OK ;
}
float f =.05;
float dx = .05;
void CBScreenSaver::Draw(BView *view, int32 frame)
{

	if (frame==0){
		Buffer = new CBBuffer(view->Bounds(), (int)(view->Bounds().bottom - view->Bounds().top)/2);
		Object = new Moff("", Buffer, i);
		if ( this->detail_slider != NULL )
			this->detail = this->detail_slider->Value();
		Create(Object, detail);
	}

		Buffer -> Clear();
		
		if ((f >= 1.0) || (f <= 0.01))
			dx = -dx;
		f += dx;
		Set(Object, f);
		Object->Roteer(-15.0,10.0,0.0);
		Object->Draw();
		Buffer->MakeReady();
		view->DrawBitmap(Buffer);

	
}
void CBScreenSaver::StopSaver() 
{
}

