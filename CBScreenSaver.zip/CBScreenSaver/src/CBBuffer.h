#ifndef DEF_CBBuffer
#define DEF_CBBuffer
#include <Bitmap.h>
#include "CBTriangle.h"
	class CBBuffer : public BBitmap{
		public :
			CBBuffer(BRect);
			CBBuffer(BRect, float);
			~CBBuffer();
			void Clear();
			void SetScale(float);
			void DrawDot(const float, const float, const float, rgb_color);
			void Line(int, int, int, int, rgb_color);
			void Point(BPoint, rgb_color);
			void DrawDot(CBTriangle&);
			void DrawWire(CBTriangle&);
			void DrawFlat(CBTriangle&);
			void DrawGourand(CBTriangle&);
			void MakeReady();
		private :
			uint32*	Buffer_data;
			float Scale;
			int width, height;
			//float *ZBuffer;
			BView *work;
	};
		
#endif