#include <ScreenSaver.h>
#include <Font.h>
#include "CBParser.h"
#include "Slider.h"

#define DETAIL_CHANGED	'CB_DETTAIL'
class CBScreenSaver : public BScreenSaver
{
	public:
		CBScreenSaver(BMessage *message, image_id id);
		~CBScreenSaver();
		virtual void StartConfig(BView *view);
		virtual void StopConfig();
		virtual void StopSaver();
		
		virtual status_t CBScreenSaver::SaveState ( BMessage* state_ ) const;
		virtual status_t StartSaver(BView *v, bool preview);
		virtual void Draw(BView *view, int32);

	private :
		CBBuffer* Buffer;
		int i, x, y,  b;
		int8 detail;
		Moff *Object;
		BSlider *detail_slider; 

};
