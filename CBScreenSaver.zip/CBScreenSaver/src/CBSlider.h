#ifndef DEF_CBSlider
#define DEF_CBSlider
#include <Slider.h>

class CBSlider : public BSlider{
	public :


		CBSlider(BRect frame, const char *label, int min, int max, int def,
				 const char *limlabl, const char *limlabr, int *target_value );
		~CBSlider();
		virtual void SetValue(int32);
		int Value();
	private:

	int *target_value;

};
#endif DEF_CBSlider