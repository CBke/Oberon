#ifndef DEF_CBFILE
#define DEF_CBFILE
#include <iostream>
#include <fstream>
#include <strstream>
#include <cctype>
class CBFile{
	public :
		CBFile(char*);
		int ReadInt();
		float ReadFloat();
	private :
		char Data[80];
		bool ok;
		ifstream *File;
};

#endif DEF_CBFILE