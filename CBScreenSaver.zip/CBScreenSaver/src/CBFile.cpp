#include "CBFile.h"

int StrToInt(char* Data);
float StrToFloat(char* Data);

void PrintFile(char* inputFileName) {
    ifstream fromFile(inputFileName, ios::in); 

	if (!fromFile)									
		cerr << "file invalid \nMake sure \""<<  inputFileName <<"\" exists.\n";
	else {
		
		char lineFromFile[70];
	
		while (!fromFile.eof()) {						
			fromFile >> lineFromFile;

			cout << StrToFloat(lineFromFile) <<endl;
		}
	}
}
bool Digit(char c){
	return ((int)c>=48)&&((int)c<=57);
}
bool Dot(char c){
	return ((int)c==46);
}
int pow(int base, int exp){
	int Value=1;
	while(exp > 0){
		Value*=base;
		exp--;
	}
	return Value; 
}
int StrToInt(char* Data){
	int Value =0;
	int pos =0;
	bool negative=false;
	
	if(((int)Data[0]) != 0)
		if ((int)Data[0] == 45)
		{
			negative = true;
			pos=1;
		}	
		else
			negative = false;
		
		if(((int)Data[pos]) != 0)
			if (Digit(Data[pos]))
				while (((int)Data[pos]) != 0)
				{
					if (Digit(Data[pos]))
					{
						Value *= 10;
						Value += (int)Data[pos]-48;
						pos++;
					}
					else
						while (((int)Data[pos]) != 0)
							pos++;
				}
	if (negative)
		Value *= -1;
	return Value; 
}
float StrToFloat(char* Data){
	float Value=0;
	int pos =0, e=0;
	bool negative=false;
	
	if(((int)Data[0]) != 0)
	{ 
		if ((int)Data[0] == 45)
		{
			negative = true;
			pos=1;
		}	
		else
	
			negative = false;
	
		
		if(((int)Data[pos]) != 0)
			if (Digit(Data[pos]))
				while (((int)Data[pos]) != 0)
					if (Digit(Data[pos]))
					{
					Value *= 10;
					Value += (int)Data[pos]-48;
					pos++;
					}
					else 
						if(Dot(Data[pos]))
						{
							pos++;
							while (((int)Data[pos]) != 0)
								if( Digit(Data[pos]))
								{
									Value *= 10;
									Value += (int)Data[pos]-48;
									e++;
									pos++;
								}
								else
								{
									pos+=2;
									e+=10*((int)Data[pos]-48)+(int)Data[pos+1]-48;
								}
						}
						else
							
							{
								pos+=2;
								e+=10*((int)Data[pos]-48)+(int)Data[pos+1]-48;
								
							}
							else
								while (((int)Data[pos]) != 0)
									pos++;	
						else
							while (((int)Data[pos]) != 0)
								pos++;
	
		}
	
	if (negative)
		Value *= -1;
	Value/=pow(10, e);
	return Value; 
	
}

int CBFile::ReadInt(){
	int RetVal=0;
	if (! File->eof()){
		*File >> Data;
		RetVal = StrToInt(Data);
	}

	return RetVal;
}

float CBFile::ReadFloat(){
	float RetVal=0;
	if (! File->eof()){
		*File >> Data;
		RetVal = StrToFloat(Data);
	}

	return RetVal;
}

CBFile::CBFile(char* FileName){

	File = new ifstream (FileName, ios::in); 

	if (!File){								
		cerr << "file invalid \nMake sure \""<<  FileName <<"\" exists.\n\b\b\b\b";
		ok = false;
	}
	else 
		ok = true;

}
