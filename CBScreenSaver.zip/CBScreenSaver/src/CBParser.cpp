#include "CBParser.h"
#include <stdio.h>
#include <String.h>
//#include "Data.h" //contains debug data...

void SetColor(rgb_color &c, int r, int g, int b){
	c.red=r; c.green=g; c.blue=b;
}
Moff::Moff(char *FileName, CBBuffer *Buffer, int m=1){
	
	mode=m;
	B = Buffer;
	M = CBMatrix();
	V = new CBVertex();
	
	Driehoek=NULL;
	
	//CUBE DEBUG...
	/*
	nt = 12;
	CBVertex v(1.,1.,1.);
	rgb_color c;
	c.red=0;	c.green=255;	c.blue=0;
	//Driehoek=new CBTriangle[1](CBVertex( 1.0,-1.0, 1.0), CBVertex( 1.0, 1.0, 1.0), CBVertex(-1.0, 1.0, 1.0), c);
	
	Driehoek=new CBTriangle[12](v, v, v, c);
	SetColor(c, 255, 0, 0);
	Driehoek[0] =CBTriangle(CBVertex( 1.0,-1.0, 1.0), CBVertex( 1.0, 1.0, 1.0), CBVertex(-1.0, 1.0, 1.0), c);
	Driehoek[1] =CBTriangle(CBVertex(-1.0, 1.0, 1.0), CBVertex(-1.0,-1.0, 1.0), CBVertex( 1.0,-1.0, 1.0), c);
	SetColor(c, 0, 255, 0);
	Driehoek[2] =CBTriangle(CBVertex( 1.0,-1.0, 1.0), CBVertex( 1.0,-1.0,-1.0), CBVertex( 1.0, 1.0, 1.0), c);
	Driehoek[3] =CBTriangle(CBVertex( 1.0, 1.0, 1.0), CBVertex( 1.0,-1.0,-1.0), CBVertex( 1.0, 1.0,-1.0), c);
	SetColor(c, 0, 0, 255);
	Driehoek[4] =CBTriangle(CBVertex(-1.0,-1.0,-1.0), CBVertex( 1.0, 1.0,-1.0), CBVertex( 1.0,-1.0,-1.0), c);
	Driehoek[5] =CBTriangle(CBVertex(-1.0,-1.0,-1.0), CBVertex(-1.0, 1.0,-1.0), CBVertex( 1.0, 1.0,-1.0), c);
	SetColor(c, 255, 0, 255);
	Driehoek[6] =CBTriangle(CBVertex(-1.0, 1.0, 1.0), CBVertex(-1.0, 1.0,-1.0), CBVertex(-1.0,-1.0, 1.0), c);
	Driehoek[7] =CBTriangle(CBVertex(-1.0,-1.0, 1.0), CBVertex(-1.0, 1.0,-1.0), CBVertex(-1.0,-1.0,-1.0), c);
	SetColor(c, 255, 255, 0);
	Driehoek[8] =CBTriangle(CBVertex(-1.0, 1.0, 1.0), CBVertex( 1.0, 1.0, 1.0), CBVertex(-1.0, 1.0,-1.0), c);
	Driehoek[9] =CBTriangle(CBVertex(-1.0, 1.0,-1.0), CBVertex( 1.0, 1.0, 1.0), CBVertex( 1.0, 1.0,-1.0), c);
	SetColor(c, 0, 255, 255);
	Driehoek[10]=CBTriangle(CBVertex( 1.0,-1.0, 1.0), CBVertex(-1.0,-1.0, 1.0), CBVertex(-1.0,-1.0,-1.0), c);
	Driehoek[11]=CBTriangle(CBVertex( 1.0,-1.0, 1.0), CBVertex(-1.0,-1.0,-1.0), CBVertex( 1.0,-1.0,-1.0), c);
	*/
	/*
	F = new CBFile(FileName);
	nt = F->ReadInt();
	//cout << "NT =" << nt << endl; 
	CBVertex v(1.,1.,1.);
	rgb_color c;
	//c.red=255;	c.green=255;	c.blue=0;
	c.red=0;	c.green=255;	c.blue=127;
	Driehoek=new CBTriangle[nt](v, v, v, c);
	for(int i=0; i< nt; i++)
		Driehoek[i]=CBTriangle(
			CBVertex( F->ReadFloat(),F->ReadFloat(), F->ReadFloat()), 
			CBVertex( F->ReadFloat(),F->ReadFloat(), F->ReadFloat()),
			CBVertex( F->ReadFloat(),F->ReadFloat(), F->ReadFloat()), c);
	cout << "Done Reading..."<<endl;
*/
/*
 
	//	BUNNY
	nt = 902;
	
	rgb_color c;
	c.red=255;	c.green=255;	c.blue=255;
	CBVertex v(.0,.0,.0);
	Driehoek=new CBTriangle[nt](v, v, v, c);
	for(int i=0; i<nt; i++)
	Driehoek[i] =CBTriangle(
	CBVertex(Bunny[i*9], Bunny[i*9+1],Bunny[i*9+2]), 
	CBVertex(Bunny[i*9+3], Bunny[i*9+4],Bunny[i*9+5]),
	CBVertex(Bunny[i*9+6], Bunny[i*9+7],Bunny[i*9+8]), c);
*/
/*
	//CUBE
	nt = 12;	
	rgb_color c;
	c.red=0;	c.green=255;	c.blue=0;
	CBVertex v(.0,.0,.0);
	Driehoek=new CBTriangle[nt](v, v, v, c);
	SetColor(c, 255, 0, 0);
	for(int i=0; i<nt; i++)
	Driehoek[i] =CBTriangle(
	CBVertex(Cube[i*9], Cube[i*9+1],Cube[i*9+2]), 
	CBVertex(Cube[i*9+3], Cube[i*9+4],Cube[i*9+5]),
	CBVertex(Cube[i*9+6], Cube[i*9+7],Cube[i*9+8]), c);
*/
	/*
	//TEST
	nt = 2;	
	rgb_color c;
	c.red=0;	c.green=255;	c.blue=0;
	CBVertex v(.0,.0,.0);
	Driehoek=new CBTriangle[nt](v, v, v, c);
	SetColor(c, 255, 0, 0);
	for(int i=0; i<nt; i++)
	Driehoek[i] =CBTriangle(
	CBVertex(Cube[i*9], Cube[i*9+1],Cube[i*9+2]), 
	CBVertex(Cube[i*9+3], Cube[i*9+4],Cube[i*9+5]),
	CBVertex(Cube[i*9+6], Cube[i*9+7],Cube[i*9+8]), c);
	*/
	/*
	//Wolf
	nt = 3610;
	
	rgb_color c;
	c.red=255;	c.green=255;	c.blue=255;
	CBVertex v(.0,.0,.0);
	Driehoek=new CBTriangle[nt](v, v, v, c);
	for(int i=0; i<nt; i++)
	Driehoek[i] =CBTriangle(
	CBVertex(Wolf[i*9], Wolf[i*9+1], Wolf[i*9+2]), 
	CBVertex(Wolf[i*9+3], Wolf[i*9+4], Wolf[i*9+5]),
	CBVertex(Wolf[i*9+6], Wolf[i*9+7], Wolf[i*9+8]), c);
	*/

};	

Moff::~Moff(){

	//delete V;
	//Dunno if this is enough...
	//delete Driehoek;
	
	
}

void Moff::SetMode(int m){
	if ((m>-1)&&(m<4))
		mode=m;
}

void Moff::Roteer(float x, float y, float z){
	CBMatrix *mx = new CBMatrix(), *my = new CBMatrix(), *mz = new CBMatrix();
	
	mx->MakeRotateX(x);
	my->MakeRotateY(y);
	mz->MakeRotateZ(z);
	
	*mz = *mx**my**mz;
	M = M**mz;

	
	V->Inverse();
	
	
	for(int i=0; i <nt; i++)
		Driehoek[i].Move(*V);
	V->Inverse();
	for(int i=0; i <nt; i++)
		Driehoek[i].Roteer(*mz);
	for(int i=0; i <nt; i++)
		Driehoek[i].Move(*V);
	delete mx;
	delete my;
	delete mz;

}
void Moff::Move(CBVertex& v){

	
	*V+=v;
	
	for(int i=0; i <nt; i++)
		Driehoek[i].Move(v);

}

void Moff::Draw(){
	switch (mode)
	{
		case Draw_Dot :{
			for(int i=0; i <nt; i++)
				B->DrawDot(Driehoek[i]);
			break;
			}
		case Draw_Wire :{
			for(int i=0; i <nt; i++)
				if (Driehoek[i].norm.z <= .0)
					B->DrawWire(Driehoek[i]);
			break;
			}
		case Draw_Flat :{
			for(int i=0; i <nt; i++)
				if (Driehoek[i].norm.z <= .0)
					B->DrawFlat(Driehoek[i]);
			break;
			}
		case Draw_Gour :{
			Calculate();
			for(int i=0; i <nt; i++)
				if (Driehoek[i].norm.z <= .0)
					B->DrawGourand(Driehoek[i]);
			
			break;
		}
		default:{
			printf("Invalid draw mode...\n");
			break;
		}
	}
}

void Moff::BeginPosition(){
	V->Inverse();
	for(int i=0; i <nt; i++)
		Driehoek[i].Move(*V);
	V->Set(.0,.0,.0);
	M.Invert();
	for(int i=0; i <nt; i++)
		Driehoek[i].Roteer(M);
	M.Reset();
	
}
void Moff::Calculate(){	//used by gourand
/*
	CBVertex n(.0,.0,.0);
	printf("Calculating\n");
	for(int i =0; i < nt; i++)
		for(int j=0; j<3; j++)
			Driehoek[i].Edge[j].Set(.0,.0,.0);
			
	for(int i =0; i < nt; i++){
		for(int j=0; j<3; j++)	{
			if (Driehoek[i].Edge[j]==n) //nog niet aan bod gekomen
			{
			int c = 0;
			for(int k=0; k <nt; k++)
				if (Driehoek[k].IsPoint(Driehoek[i].Dot[j])){
					Driehoek[i].Edge[j] = Driehoek[i].Edge[j] +Driehoek[k].norm;
					c++;
					}
				Driehoek[i].Edge[j].Normalize();
			}
		}
		
	}
*/
}

float Function(const float x, const float y, const float Percent){
	float Value=.0;
	for(int i=0; i<6; i++)
		Value += (Percent*c[i]*exp(-((x-u[i])*(x-u[i])/a[i])-((-y-v[i])*(-y-v[i])/b[i])));
///	Value =sin(x*10.0)*cos(y*10.0)/5.0;
	return Value;
}


void Create(Moff *M, int Precision){
	M->	nt = 2*Precision*Precision*100;	
	rgb_color c;
	SetColor(c, 255, 255, 255);
	CBVertex v(.0,.0,.0);
//	if (M->Driehoek != NULL)
//		delete M->Driehoek;
	M->Driehoek=new CBTriangle[M->nt](v, v, v, c);
	Set(M, .0);
}
void Set(Moff *M, float Percent){
	int Precision = (int)(sqrt(M->nt/200));
	int nr;
	float x, y, z;
	rgb_color c;
	SetColor(c, 255, 255, 255);
	CBVertex v1, v2, v3;
	float small = (.2/Precision);

	
	for(int i=0; i<Precision*10; i++)
		for(int j=0; j<Precision*10; j++)
		{
			nr =(i*Precision*10+j)*2;
			
			x = small*(i) -1.0;
			y = small*(j) -1.0;
			z = Function(x, y, Percent);
			v1 = CBVertex(x, y ,z);
			x = small*(i+1) -1.0;
			y = small*(j) -1.0;
			z = Function(x, y, Percent);
			v2 = CBVertex(x, y ,z);
			x = small*(i) -1.0;
			y = small*(j+1) -1.0;
			z = Function(x, y, Percent);
			v3 = CBVertex(x, y ,z);
			M->Driehoek[nr]= CBTriangle(v1, v2, v3, c);
	
			x = small*(i+1) -1.0;
			y = small*(j) -1.0;
			z = Function(x, y, Percent);
			v1 = CBVertex(x, y ,z);
			x = small*(i+1) -1.0;
			y = small*(j+1) -1.0;
			z = Function(x, y, Percent);
			v2 = CBVertex(x, y ,z);
			x = small*(i) -1.0;
			y = small*(j+1) -1.0;
			z = Function(x, y, Percent);
			v3 = CBVertex(x, y ,z);
			M->Driehoek[nr+1] =CBTriangle(v1, v2, v3, c);
 
					
		}
	
}

