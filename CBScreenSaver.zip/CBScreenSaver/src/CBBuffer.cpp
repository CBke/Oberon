#include "CBBuffer.h"
#include <stdio.h>
#include <View.h>
const float eps0 = 0.0 + 1.0e-15,
			eps1 = 1.0 - 1.0e-15;


CBBuffer::CBBuffer(BRect rect) : BBitmap(rect ,B_RGB32, true){
	Buffer_data = (uint32*)Bits();
	Scale = 1.0;
	width = (int)(rect.right - rect.left);
	height = (int)(rect.bottom - rect.top);
	//ZBuffer = new float[width*height];
	work = NULL;
}
CBBuffer::CBBuffer(BRect rect, float s) : BBitmap(rect ,B_RGB32, true){
	Buffer_data = (uint32*)Bits();
	width = (int)(rect.right - rect.left)+1;
	height = (int)(rect.bottom - rect.top)+1;
	Scale = s;
	//ZBuffer = new float[width*height];
	//for (long i=0; i < width*height; i++)
	//	ZBuffer[i] = -1.0e+20;
	work = NULL;
}
void CBBuffer::SetScale(float s){
	if(s > 0) Scale = s;
}
CBBuffer::~CBBuffer(){
	if (work != NULL)
		RemoveChild(work);
	//delete work;
	//delete ZBuffer;
};

void CBBuffer::Clear(){
	//BView *view = new BView(Bounds(),NULL,B_FOLLOW_LEFT|B_FOLLOW_TOP,B_WILL_DRAW);
	//AddChild(view);
	//Lock();
	//rgb_color c;
	//c.red=255; c.green=255; c.blue=255;
	//view->SetHighColor(c);
	//view->FillRect(Bounds());
	//RemoveChild(view);
	uint32* bits=(uint32*)Bits();//+y*(BytesPerRow()/4)+x;
	for(long i = 0; i <width*height; i++){
		*bits=0x00000000;
		bits++;
		//ZBuffer[i] = -1.0e+20;
		}
	//delete view;
	//for (long i=0; i < width*height; i++)
		
}
void CBBuffer::DrawDot(const float px, const float py, const float d, rgb_color c)
{	/*
	int x=(int)(Scale*px+width/2),
		y=(int)(Scale*py+height/2);
	*/
	int x=(int)(px+width/2),
		y=(int)(py+height/2);
	if ((x >= 0) && (y >= 0) && (x < width) && (y < height)){
	//	if (d > ZBuffer[x+y*width])
	//	{
			uint32* bits=(uint32*)Bits()+y*(BytesPerRow()/4)+x;
			*(bits)= (uint32)(c.red*0x00010000+c.green*0x00000100+c.blue*0x00000001);
			//ZBuffer[x+y*width] = d;
	//	}
	}
}
/*
void CBBuffer::Point(BPoint p, rgb_color c){
	DrawDot(p.x, p.y, c); 
}
*/
void CBBuffer::DrawDot(CBTriangle& t){

	DrawDot(Scale*t.Dot[0].x, Scale*t.Dot[0].y, .0, t.col);
	DrawDot(Scale*t.Dot[1].x, Scale*t.Dot[1].y, .0, t.col);
	DrawDot(Scale*t.Dot[2].x, Scale*t.Dot[2].y, .0, t.col);
}

void CBBuffer::Line(int x0, int y0, int x1, int y1, rgb_color c)
{
	int dx=x1-x0, dy=y1-y0, p;
	int incx = 1;
	if(dx < 0)
		incx = -1;
	int incy = 1;
	if(dy < 0)
		incy = -1;
	if (dx > dy) // yvarieren
	{
		
		dy = abs(dy);
		dx = abs(dx);
		p = 2*dx-dy;
		if((dx < 0)||(dy<0)) 
			printf ("jongen daar klop gene klood van abs\n");
		//////////////
		if ((x0 >= 0) && (y0 >= 0) && (x0 < width) && (y0 < height)){
			uint32* bits=(uint32*)Bits()+y0*(BytesPerRow()/4)+x0;
			*(bits)= (uint32)(c.red*0x00010000+c.green*0x00000100+c.blue*0x00000001);
		}
		///////////////
		while (y0!=y1)
		{
		//////////////
			if ((x0 >= 0) && (y0 >= 0) && (x0 < width) && (y0 < height)){
				uint32* bits=(uint32*)Bits()+y0*(BytesPerRow()/4)+x0;
				*(bits)= (uint32)(c.red*0x00010000+c.green*0x00000100+c.blue*0x00000001);
			}
		///////////////
		
	
			if(p<=0)
				p += 2*dx;
			else
			{
				p += 2*dx-2*dy;
				x0+=incx;
			}
			y0+=incy;
		}
	}
	else
	{	
		
		dy = abs(dy);
		dx = abs(dx);
		p = 2*dy-dx;
		//////////////
		if ((x0 >= 0) && (y0 >= 0) && (x0 < width) && (y0 < height)){
			uint32* bits=(uint32*)Bits()+y0*(BytesPerRow()/4)+x0;
			*(bits)= (uint32)(c.red*0x00010000+c.green*0x00000100+c.blue*0x00000001);
		}
		///////////////
		while (x0!=x1)
		{
		//////////////
		if ((x0 >= 0) && (y0 >= 0) && (x0 < width) && (y0 < height)){
			uint32* bits=(uint32*)Bits()+y0*(BytesPerRow()/4)+x0;
			*(bits)= (uint32)(c.red*0x00010000+c.green*0x00000100+c.blue*0x00000001);
		}
		///////////////
			if(p<=0)
				p += 2*dy;
			else
			{
				p += 2*dy-2*dx;
				y0+=incy;
			}
			x0+=incx;
		}
	}

}
void CBBuffer::DrawWire(CBTriangle& t){
/*
BView *view = new BView(Bounds(),NULL,B_FOLLOW_LEFT|B_FOLLOW_TOP,B_WILL_DRAW);
	AddChild(view);
	Lock();
	view->SetHighColor(t.col);
	
	view->StrokeLine(BPoint(Scale*t.Dot[0].x+width/2, Scale*t.Dot[0].y+height/2),	BPoint(Scale*t.Dot[1].x+width/2, Scale*t.Dot[1].y+height/2));
	view->StrokeLine(BPoint(Scale*t.Dot[1].x+width/2, Scale*t.Dot[1].y+height/2),	BPoint(Scale*t.Dot[2].x+width/2, Scale*t.Dot[2].y+height/2));
	view->StrokeLine(BPoint(Scale*t.Dot[0].x+width/2, Scale*t.Dot[0].y+height/2),	BPoint(Scale*t.Dot[2].x+width/2, Scale*t.Dot[2].y+height/2));
	
	RemoveChild(view);
	delete view;
*/
	Line(int(Scale*t.Dot[0].x+width/2), int(Scale*t.Dot[0].y+height/2),	int(Scale*t.Dot[1].x+width/2), int(Scale*t.Dot[1].y+height/2), t.col);
	Line(int(Scale*t.Dot[1].x+width/2), int(Scale*t.Dot[1].y+height/2),	int(Scale*t.Dot[2].x+width/2), int(Scale*t.Dot[2].y+height/2), t.col);
	Line(int(Scale*t.Dot[0].x+width/2), int(Scale*t.Dot[0].y+height/2),	int(Scale*t.Dot[2].x+width/2), int(Scale*t.Dot[2].y+height/2), t.col);
	
}

int InvalideLambda(float l1, float l2, float l3)
{

	if ((l1 < eps0) || (l1 > eps1))
		return 1;
	else if ((l2 < eps0) || (l2 > eps1))
		return 2;
	else if ((l3 < eps0) || (l3 > eps1))
		return 3;
	else {
		if ((l1 <= eps0) || (l1 >= eps1))
			return 1;
		else if ((l2 <= eps0) || (l2 >= eps1))
			return 2;
		else if ((l3 <= eps0) || (l3 >= eps1))
			return 3;
		else
			return -1; //inclrrect labda's
	}
	
}

void CBBuffer::DrawFlat(CBTriangle& t){
CBVertex light(1.5,0.5,-2.0);	
	light.Normalize();
	rgb_color c=t.col;
	CBVertex *v = new CBVertex();
	*v = t.norm*light;
	float a = 1.0-sqrt(v->x*v->x+v->y*v->y)/1.5;
	delete v;
	c.red = (int)(c.red*a);
	c.green = (int)(c.green*a);
	c.blue = (int)(c.blue*a);
	if (work == NULL)
	{
		work = new BView(Bounds(),NULL,B_FOLLOW_LEFT|B_FOLLOW_TOP,B_WILL_DRAW);
		AddChild(work);
		Lock();
	}
	work->SetHighColor(c);
	
	
	work->FillTriangle(BPoint(Scale*t.Dot[0].x+width/2,Scale*t.Dot[0].y+ height/2),
	BPoint(Scale*t.Dot[1].x+width/2,Scale*t.Dot[1].y+height/2),
	BPoint(Scale*t.Dot[2].x+width/2,Scale*t.Dot[2].y+height/2));
	
	/*
	work->StrokeLine(BPoint(Scale*t.Dot[0].x+width/2, Scale*t.Dot[0].y+height/2),	BPoint(Scale*t.Dot[1].x+width/2, Scale*t.Dot[1].y+height/2));
	work->StrokeLine(BPoint(Scale*t.Dot[1].x+width/2, Scale*t.Dot[1].y+height/2),	BPoint(Scale*t.Dot[2].x+width/2, Scale*t.Dot[2].y+height/2));
	work->StrokeLine(BPoint(Scale*t.Dot[0].x+width/2, Scale*t.Dot[0].y+height/2),	BPoint(Scale*t.Dot[2].x+width/2, Scale*t.Dot[2].y+height/2));
	*/
	//RemoveChild(view);
	//delete view;
	
/*	
	int maxy = (int)(t.MaxPar()*Scale), Left=0, Right=0,
	miny = (int)(t.MinPar()*Scale);
	
	if (0 < miny)
		miny++;
	
	if(maxy > 0)
		maxy++;
	
	CBVertex light(1.5,0.5,1.0);	
	light.Normalize();
	rgb_color c=t.col;
	CBVertex *v = new CBVertex();
	*v = t.norm*light;
	float a = 1.0-sqrt(v->x*v->x+v->y*v->y)/1.5;
	delete v;
	c.red = (int)(c.red*a);
	c.green = (int)(c.green*a);
	c.blue = (int)(c.blue*a);
	float lambda1, lambda2, lambda3, depth = (t.Dot[0].z+t.Dot[1].z+t.Dot[2].z)/3;
	 
	for(int Scanny=miny; Scanny < maxy; Scanny++){
	
	
		if (t.Dot[1].y- t.Dot[0].y)
			lambda1 = (Scanny/Scale-t.Dot[0].y) / (t.Dot[1].y- t.Dot[0].y);
		else
			lambda1 = Scanny/Scale-t.Dot[0].y;
	
								
		if (t.Dot[2].y- t.Dot[0].y)
			lambda2 = (Scanny/Scale-t.Dot[0].y) / (t.Dot[2].y- t.Dot[0].y);
		else
			lambda2 = Scanny/Scale-t.Dot[0].y;
		
								
		if (t.Dot[2].y- t.Dot[1].y)
			lambda3 = (Scanny/Scale-t.Dot[1].y) / (t.Dot[2].y- t.Dot[1].y);
		else
			lambda3 = Scanny/Scale-t.Dot[1].y;
														
		switch (InvalideLambda(lambda1, lambda2, lambda3))
		{
			case 1:{
				
				Left = (int)(Scale*(t.Dot[0].x+lambda2*(t.Dot[2].x-t.Dot[0].x)));
				Right = (int)(Scale*(t.Dot[1].x+lambda3*(t.Dot[2].x-t.Dot[1].x)));
				if (Left > Right){
					Right = (int)(Scale*(t.Dot[0].x+lambda2*(t.Dot[2].x-t.Dot[0].x)));
					Left = (int)(Scale*(t.Dot[1].x+lambda3*(t.Dot[2].x-t.Dot[1].x)));
				}
				
				break;
			}
			case 2:{
				
				Left = (int)(Scale*(t.Dot[0].x+lambda1*(t.Dot[1].x-t.Dot[0].x)));
				Right = (int)(Scale*(t.Dot[1].x+lambda3*(t.Dot[2].x-t.Dot[1].x)));
				if (Left > Right){
					Right = (int)(Scale*(t.Dot[0].x+lambda1*(t.Dot[1].x-t.Dot[0].x)));
					Left = (int)(Scale*(t.Dot[1].x+lambda3*(t.Dot[2].x-t.Dot[1].x)));
				}	
				
				break;
			}
			case 3:{
				
				Left = (int)(Scale*(t.Dot[0].x+lambda1*(t.Dot[1].x-t.Dot[0].x)));
				Right = (int)(Scale*(t.Dot[0].x+lambda2*(t.Dot[2].x-t.Dot[0].x)));
				if (Left > Right){
					Right = (int)(Scale*(t.Dot[0].x+lambda1*(t.Dot[1].x-t.Dot[0].x)));
					Left = (int)(Scale*(t.Dot[0].x+lambda2*(t.Dot[2].x-t.Dot[0].x)));
				}	
				
				break;
			}
			default :{
				//printf("DEBUG !!!!!!\n");
				break;
			}
		};//case
		
		
		for(int Scannix=Left; Scannix<=Right; Scannix++)
			DrawDot(Scannix, Scanny, depth, c);
		
		
	}//Scanny
	*/
}
void CBBuffer::DrawGourand(CBTriangle& t)
{
	/*
	int maxy = (int)(t.MaxPar()*Scale), Left=0, Right=0,
	miny =(int)(t.MinPar()*Scale);
	CBVertex LeftV, RightV, CV;
	if (0 <= miny)
		miny++;
	
	if(maxy>=0)
		maxy++;
	float lambda1, lambda2, lambda3,depth = (t.Dot[0].z+t.Dot[1].z+t.Dot[2].z)/3;
	for(int Scanny=miny; Scanny < maxy; Scanny++){
	
	
		if (t.Dot[1].y- t.Dot[0].y)
			lambda1 = (Scanny/Scale-t.Dot[0].y) / (t.Dot[1].y- t.Dot[0].y);
		else
			lambda1 = Scanny/Scale-t.Dot[0].y;
	
								
		if (t.Dot[2].y- t.Dot[0].y)
			lambda2 = (Scanny/Scale-t.Dot[0].y) / (t.Dot[2].y- t.Dot[0].y);
		else
			lambda2 = Scanny/Scale-t.Dot[0].y;
		
								
		if (t.Dot[2].y- t.Dot[1].y)
			lambda3 = (Scanny/Scale-t.Dot[1].y) / (t.Dot[2].y- t.Dot[1].y);
		else
			lambda3 = Scanny/Scale-t.Dot[1].y;
														
		switch (InvalideLambda(lambda1, lambda2, lambda3))
		{
			case 1:{
				
				Left = (int)(Scale*(t.Dot[0].x+lambda2*(t.Dot[2].x-t.Dot[0].x)));
				Right = (int)(Scale*(t.Dot[1].x+lambda3*(t.Dot[2].x-t.Dot[1].x)));
				LeftV = t.Edge[0]+(t.Edge[2]-t.Edge[0])*lambda2;
				RightV = t.Edge[1]+(t.Edge[2]-t.Edge[1])*lambda3;
				if (Left > Right){
					Right = (int)(Scale*(t.Dot[0].x+lambda2*(t.Dot[2].x-t.Dot[0].x)));
					Left = (int)(Scale*(t.Dot[1].x+lambda3*(t.Dot[2].x-t.Dot[1].x)));
					RightV = t.Edge[0]+(t.Edge[2]-t.Edge[0])*lambda2;
					LeftV = t.Edge[1]+(t.Edge[2]-t.Edge[1])*lambda3;
				}
				
				break;
			}
			case 2:{
				
				Left = (int)(Scale*(t.Dot[0].x+lambda1*(t.Dot[1].x-t.Dot[0].x)));
				Right = (int)(Scale*(t.Dot[1].x+lambda3*(t.Dot[2].x-t.Dot[1].x)));
				LeftV = t.Edge[0]+(t.Edge[1]-t.Edge[0])*lambda1;
				RightV = t.Edge[1]+(t.Edge[2]-t.Edge[1])*lambda3;
				if (Left > Right){
					Right = (int)(Scale*(t.Dot[0].x+lambda1*(t.Dot[1].x-t.Dot[0].x)));
					Left = (int)(Scale*(t.Dot[1].x+lambda3*(t.Dot[2].x-t.Dot[1].x)));
					RightV = t.Edge[0]+(t.Edge[1]-t.Edge[0])*lambda1;
					LeftV = t.Edge[1]+(t.Edge[2]-t.Edge[1])*lambda3;
				}	
				
				break;
			}
			case 3:{
				
				Left = (int)(Scale*(t.Dot[0].x+lambda1*(t.Dot[1].x-t.Dot[0].x)));
				Right = (int)(Scale*(t.Dot[0].x+lambda2*(t.Dot[2].x-t.Dot[0].x)));
				LeftV = t.Edge[0]+(t.Edge[1]-t.Edge[0])*lambda1;
				RightV = t.Edge[0]+(t.Edge[2]-t.Edge[0])*lambda2;
				if (Left > Right){
					Right = (int)(Scale*(t.Dot[0].x+lambda1*(t.Dot[1].x-t.Dot[0].x)));
					Left = (int)(Scale*(t.Dot[0].x+lambda2*(t.Dot[2].x-t.Dot[0].x)));
					RightV = t.Edge[0]+(t.Edge[1]-t.Edge[0])*lambda1;
					LeftV = t.Edge[0]+(t.Edge[2]-t.Edge[0])*lambda2;
				}
				
				break;
			}
			default :{
				//printf("DEBUG !!!!!!\n");
				break;
			}
		};//case
		
		
		for(int Scannix=Left; Scannix<=Right; Scannix++){
			if (Right-Left)
				CV = LeftV +(RightV-LeftV)*((Scannix-Left)/(Right-Left));
			else
				CV = LeftV;
			rgb_color c=t.col;
			float a = 1.0-sqrt(CV.x*CV.x+CV.y*CV.y)/1.5;
			c.red = (int)(c.red*a);
			c.green = (int)(c.green*a);
			c.blue = (int)(c.blue*a);
	
			DrawDot(Scannix, Scanny, depth, c);
		}
		
	}//Scanny
	*/
}

void CBBuffer::MakeReady()
{
	RemoveChild(work);
	delete work;
	work = NULL;
}
