#ifndef DEF_CBTRIANGLE
#define DEF_CBTRIANGLE
#include <Bitmap.h>
#include "CBVertex.h"

class CBTriangle{
	public :
		CBTriangle(const CBVertex&, const CBVertex&, const CBVertex&, rgb_color);
		//void Set(const CBVertex&, const CBVertex&, const CBVertex&, rgb_color);
		void Roteer(CBMatrix&);
		void Move(CBVertex&);
		bool IsPoint(CBVertex&);
		float MinPar();
		float MaxPar();
		//float minPer() const;
		//float maxPer() const;
		
		// moeten nog private  worden
		CBVertex norm;
		CBVertex Dot[3];
		//CBVertex Edge[3];
		float Depth;
		rgb_color col; 
};
#endif CD_CBTRIANGLE