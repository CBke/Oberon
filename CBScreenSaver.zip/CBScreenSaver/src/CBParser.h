
#ifndef DEF_CBPARSER
#define DEF_CBPARSER
#include "CBVertex.h"
#include "CBTriangle.h"
#include "CBBuffer.h"
#include "CBFile.h"
const float u[6]={.0,.0,-0.2,0.2,.0,.0};
const float v[6]={.25,.0,.25,.25,-0.5,-0.2};
const float a[6]={.5,.02,.04,.04,.05,.08};
const float b[6]={1.0,.05,.02,.02,.05,.02};
const float c[6]={.7,.3,-0.2,-0.2,.3,-0.1};

const int Draw_Dot=0,
	Draw_Wire=1,
	Draw_Flat=2,
	Draw_Gour=3;

class Moff{
	public:

		Moff(char *, CBBuffer*, int mode=1);
		~Moff();
		
		void SetMode(int);
		void Roteer(float, float, float);
		void Move(CBVertex&);
		void BeginPosition();
		void Draw();
		// moeten nog private worden
		CBTriangle *Driehoek;
		long nt;
	private :
		CBFile *F;
		CBBuffer *B;
		int mode;
		CBMatrix M;
		CBVertex *V;
		void Calculate();
		
};

void Create(Moff *, int); // 1-10
void Set(Moff *, float); //]0.0, 1.0[
float Function(float, float, float);

#endif DEF_CBPARSER