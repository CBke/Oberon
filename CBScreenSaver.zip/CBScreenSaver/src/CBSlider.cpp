#include "CBSlider.h"
#include <stdlib.h>
#include <stdio.h>
CBSlider::CBSlider(BRect frame, const char *label, int min, int max, int def,
				 const char *limlabl, const char *limlabr,
				 int *target_value ): BSlider(frame, 0, label, 0, min, max)
	{
	
		this->target_value=target_value ;
		ResizeToPreferred();
		SetLimitLabels(limlabl, limlabr);
		SetHashMarkCount(max - min + 1);
		SetHashMarks(B_HASH_MARKS_BOTTOM);
		SetValue(def);
		BSlider::SetValue(def);

	}
	void CBSlider::SetValue(int32 value)

	{

		if (target_value)
			*target_value =  (int)value;
		BSlider::SetValue(value);

	}
	
	CBSlider::~CBSlider(){
		//target_value = NULL;
	}