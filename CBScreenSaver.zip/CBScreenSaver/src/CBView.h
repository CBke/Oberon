#ifndef CB_VIEW_DEF
#define CB_VIEW_DEF
#include <View.h>
#include "CBTriangle.h"
#include "CBParser.h"
#include "CBBuffer.h"
class CBView : public BView{
	public :
		
		CBView (BRect frame);
		~CBView();
		
		void MouseDown(BPoint point);
		void MouseMoved(BPoint point, uint32 transit, BMessage *message);
		void KeyDown(const char*,int32);
		
		void Flash();
		void Action();
		
	private :
		CBBuffer* Buffer;
		int i;
		BView* WorkView;
		Moff *Object;
};
#endif