/*

		a small vertex implemenetation

*/


#include "CBVertex.h"

#include <math.h>
#include <stdio.h>

CBVertex::CBVertex() : x(0), y(0), z(0){}
CBVertex::CBVertex(const CBVertex& v){
	*this = v;
}
CBVertex::CBVertex(float xp, float yp, float zp): x(xp), y(yp), z(zp){}

void CBVertex::Set(float x0, float y0, float z0){
	x=x0; y=y0; z=z0;
}

void CBVertex::Inverse(){
	x=-x; y=-y; z=-z;
}
float CBVertex::Length() const {
	return	sqrt(x*x+y*y+z*z);
}

void CBVertex::Normalize(){
	float l = Length();
	if (l)
		Set(x/l, y/l, z/l);
	else
		Set(0,0,0);
}
void CBVertex::Normalize(const CBVertex& v){
	*this = v;
	Normalize();
}

CBVertex& CBVertex::operator+(const CBVertex& v){
	 //Set(x+v.x, y+v.y, z+v.z);
	 return *new CBVertex(x+v.x, y+v.y, z+v.z);
}

CBVertex& CBVertex::operator-(const CBVertex& v){
	//Set(x-v.x, y-v.y, z-v.z);
	return *new CBVertex(x-v.x, y-v.y, z-v.z);//*this;
}
CBVertex& CBVertex::operator+=(const CBVertex& v){
	x+=v.x;	y+=v.y;	z+=v.z;
	return *this;
}
CBVertex& CBVertex::operator-=(const CBVertex& v){
	x-= v.x; y-=v.y; z-= v.z;
	return *this;
}
float CBVertex::Sproduct(CBVertex v) const{
	return  x*v.x+y*v.y+z*v.z;

}

CBVertex& CBVertex::operator=(const CBVertex& v){
	Set(v.x, v.y, v.z);
	return *this;
}

CBVertex& CBVertex::operator*(CBVertex& v){
	//Set((y*v.z)-(z*v.y),(z*v.x)-(x*v.z),(x*v.y)-(y*v.x));
	return *new CBVertex((y*v.z)-(z*v.y),(z*v.x)-(x*v.z),(x*v.y)-(y*v.x)); //*this;
}

CBVertex& CBVertex::operator*(const CBMatrix& m){
	CBVertex v=CBVertex(x, y, z);
	v.Set(x, y, z);
	v.x=(m.Matrix[0][0]*x+m.Matrix[1][0]*y+m.Matrix[2][0]*z);
	v.y=(m.Matrix[0][1]*x+m.Matrix[1][1]*y+m.Matrix[2][1]*z);
	v.z=(m.Matrix[0][2]*x+m.Matrix[1][2]*y+m.Matrix[2][2]*z);
	*this = v;
	return *this;
	//?????????????????????????
}

CBVertex& CBVertex::operator*(float f){
	Set(x*f, y*f, z*f);
	return *this;
}

CBVertex& CBVertex::operator*=(float f){
	Set(x*f, y*f, z*f);
	return *this;
}
CBVertex& CBVertex::operator*=(const CBMatrix& m){
	CBVertex v=CBVertex(x, y, z);
	v.x=(m.Matrix[0][0]*x+m.Matrix[1][0]*y+m.Matrix[2][0]*z);
	v.y=(m.Matrix[0][1]*x+m.Matrix[1][1]*y+m.Matrix[2][1]*z);
	v.z=(m.Matrix[0][2]*x+m.Matrix[1][2]*y+m.Matrix[2][2]*z);
	*this = v;
	return *this;
}
CBVertex& CBVertex::operator/=(float f){
	if (f)
		Set(x/f, y/f, z/f);
	else
		Set(0,0,0);
	return *this;
}
bool CBVertex::operator==(const CBVertex& v){
	if (v.x ==x)
		if(v.y == y)
			if(v.z==z)
				return 1;
			else
				return 0;
		else
			return 0;
	else
		return 0;
}
void CBVertex::Print(){
	printf("x : %f\ty :%f\tz : %f\n",x, y, z);
}

void CBVertex::Printlength(){
	printf("lengte %f\n", Length());
}


CBVertex::~CBVertex(){}

