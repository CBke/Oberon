
#include "CBMatrix.h"
#include <stdio.h>
#include <math.h>

CBMatrix::CBMatrix()
{
	Matrix[0][0]=1.0;	Matrix[0][1]=0.0;	Matrix[0][2]=0.0;
	Matrix[1][0]=0.0;	Matrix[1][1]=1.0;	Matrix[1][2]=0.0;
	Matrix[2][0]=0.0;	Matrix[2][1]=0.0;	Matrix[2][2]=1.0;
	
}
void CBMatrix::Reset(){
	Matrix[0][0]=1.0;	Matrix[0][1]=0.0;	Matrix[0][2]=0.0;
	Matrix[1][0]=0.0;	Matrix[1][1]=1.0;	Matrix[1][2]=0.0;
	Matrix[2][0]=0.0;	Matrix[2][1]=0.0;	Matrix[2][2]=1.0;
}

void CBMatrix::MakeRotateX(float alpha){
	alpha=alpha*M_PI/180.0;
	Matrix[0][0]=1.0;	Matrix[1][0]=0.0; 			Matrix[2][0]=0.0;
	Matrix[0][1]=0.0;	Matrix[1][1]=cos(alpha);	Matrix[2][1]=-sin(alpha);
	Matrix[0][2]=0.0;	Matrix[1][2]=sin(alpha);	Matrix[2][2]=cos(alpha);
}

void CBMatrix::MakeRotateY(float alpha){
	alpha=alpha*M_PI/180.0;
	Matrix[0][0]=cos(alpha);	Matrix[1][0]=0.0;	Matrix[2][0]=sin(alpha);
	Matrix[0][1]=0.0;			Matrix[1][1]=1.0;	Matrix[2][1]=0.0;
	Matrix[0][2]=-sin(alpha);	Matrix[1][2]=0.0;	Matrix[2][2]=cos(alpha);
}

void CBMatrix::MakeRotateZ(float alpha){
	alpha=alpha*M_PI/180.0;
	Matrix[0][0]=cos(alpha);	Matrix[1][0]=-sin(alpha);	Matrix[2][0]=0.0;
	Matrix[0][1]=sin(alpha);	Matrix[1][1]=cos(alpha);	Matrix[2][1]=0.0;
	Matrix[0][2]=0.0;			Matrix[1][2]=0.0;			Matrix[2][2]=1.0;
}

CBMatrix& CBMatrix::MakeMeRotateX(float alpha){
//	CBMatrix *m=new CBMatrix();
	//m->
	MakeRotateX(alpha);
	return *this;
}

CBMatrix& CBMatrix::MakeMeRotateY(float alpha){
	//	CBMatrix *m=new CBMatrix();
	//m->
	MakeRotateY(alpha);
	return *this;
}

CBMatrix& CBMatrix::MakeMeRotateZ(float alpha){
	//CBMatrix *m=new CBMatrix();
	//m->
	MakeRotateZ(alpha);
	return *this;
}

CBMatrix& CBMatrix::operator+(const CBMatrix& m2){
	//CBMatrix *m3 = new CBMatrix();
	Matrix[0][0]=Matrix[0][0]+m2.Matrix[0][0];	Matrix[0][1]=Matrix[0][1]+m2.Matrix[0][1];	Matrix[0][2]=Matrix[0][2]+m2.Matrix[0][2];
	Matrix[1][0]=Matrix[1][0]+m2.Matrix[1][0];	Matrix[1][1]=Matrix[1][1]+m2.Matrix[1][1];	Matrix[1][2]=Matrix[1][2]+m2.Matrix[1][2];
	Matrix[2][0]=Matrix[2][0]+m2.Matrix[2][0];	Matrix[2][1]=Matrix[2][1]+m2.Matrix[2][1];	Matrix[2][2]=Matrix[2][2]+m2.Matrix[2][2];
	return *this;
}

CBMatrix& CBMatrix::operator-(const CBMatrix& m2){
	//CBMatrix *m3 = new CBMatrix();
	Matrix[0][0]=Matrix[0][0]-m2.Matrix[0][0];	Matrix[0][1]=Matrix[0][1]-m2.Matrix[0][1];	Matrix[0][2]=Matrix[0][2]-m2.Matrix[0][2];
	Matrix[1][0]=Matrix[1][0]-m2.Matrix[1][0];	Matrix[1][1]=Matrix[1][1]-m2.Matrix[1][1];	Matrix[1][2]=Matrix[1][2]-m2.Matrix[1][2];
	Matrix[2][0]=Matrix[2][0]-m2.Matrix[2][0];	Matrix[2][1]=Matrix[2][1]-m2.Matrix[2][1];	Matrix[2][2]=Matrix[2][2]-m2.Matrix[2][2];
	return *this;
}

CBMatrix& CBMatrix::operator*(const CBMatrix& m2){
	CBMatrix *m3=new CBMatrix();
	float tmp;
	for(int i=0; i<3; i++)
		for(int j=0; j<3; j++){
			tmp=0.0;
			for(int k=0; k<3; k++)
				tmp+=Matrix[i][k]*m2.Matrix[k][j];
			m3->Matrix[i][j]=tmp;
		};
	*this = *m3;
	delete m3;
	return *this;
}

CBMatrix& CBMatrix::operator/(const CBMatrix& m2){
	printf("Ik ben nog niet geimplementeerd...");
	return *this;
}


CBMatrix& CBMatrix::operator+=(const float f){
	Matrix[0][0]+=f;	Matrix[0][1]+=f;	Matrix[0][2]+=f;
	Matrix[1][1]+=f;	Matrix[1][1]+=f;	Matrix[1][2]+=f;
	Matrix[2][2]+=f;	Matrix[2][1]+=f;	Matrix[2][2]+=f;
	return *this;
}

CBMatrix& CBMatrix::operator-=(const float f){
	Matrix[0][0]-=f;	Matrix[0][1]-=f;	Matrix[0][2]-=f;
	Matrix[1][1]-=f;	Matrix[1][1]-=f;	Matrix[1][2]-=f;
	Matrix[2][2]-=f;	Matrix[2][1]-=f;	Matrix[2][2]-=f;
	return *this;
}

CBMatrix& CBMatrix::operator*=(const CBMatrix& m){
	CBMatrix *m2=new CBMatrix();
	float tmp;
	for (int r=0; r <3; r++){
		for(int k=0; k<3; k++){
			tmp = 0.0;
			for (int i=0; i<3; i++)
				tmp+=m.Matrix[r][i]*Matrix[i][k];
			m2->Matrix[r][k]=tmp;
		}
	}
	*this = *m2;
	delete m2;
	return *this;
}

CBMatrix& CBMatrix::operator*=(const float f){
	Matrix[0][0]*=f;	Matrix[0][1]*=f;	Matrix[0][2]*=f;
	Matrix[1][1]*=f;	Matrix[1][1]*=f;	Matrix[1][2]*=f;
	Matrix[2][2]*=f;	Matrix[2][1]*=f;	Matrix[2][2]*=f;
	return *this;
}

CBMatrix& CBMatrix::operator/=(const float f){
	if (f){
		Matrix[0][0]/=f;	Matrix[0][1]/=f;	Matrix[0][2]/=f;
		Matrix[1][1]/=f;	Matrix[1][1]/=f;	Matrix[1][2]/=f;
		Matrix[2][2]/=f;	Matrix[2][1]/=f;	Matrix[2][2]/=f;
	}
	else
		Reset();
	return *this;
}

void CBMatrix::Transponeer(){
	CBMatrix *m2 = new CBMatrix();
	for(int i=0; i<3; i++)
		for(int j=0; j<3; j++)
			m2->Matrix[i][j]=Matrix[j][i];
	*this = *m2;
	delete m2;
}

void CBMatrix::Invert(){
	/*
	Deretminant == 1 !!!	(rotatie matrix remember ?!?)
	CBMatrix *m=new CBMatrix();
	
	m->Matrix[0][0]=Matrix[1][1]*Matrix[2][2]-Matrix[2][1]*Matrix[1][2];	m->Matrix[1][0]=Matrix[2][0]*Matrix[1][2]-Matrix[1][0]*Matrix[2][2];	m->Matrix[2][0]=Matrix[1][0]*Matrix[2][1]-Matrix[2][0]*Matrix[1][1];
	m->Matrix[0][1]=Matrix[2][1]*Matrix[0][2]-Matrix[0][1]*Matrix[2][2];	m->Matrix[1][1]=Matrix[0][0]*Matrix[2][2]-Matrix[2][0]*Matrix[0][2];	m->Matrix[2][1]=Matrix[2][0]*Matrix[0][1]-Matrix[0][0]*Matrix[2][1];
	m->Matrix[0][2]=Matrix[0][1]*Matrix[1][2]-Matrix[1][1]*Matrix[0][2];	m->Matrix[1][2]=Matrix[1][0]*Matrix[0][2]-Matrix[0][0]*Matrix[1][2];	m->Matrix[2][2]=Matrix[0][0]*Matrix[1][1]-Matrix[1][0]*Matrix[0][1];
	*this = *m;
	*/
	Transponeer();
}

CBMatrix& CBMatrix::Getransponeerde(){
	CBMatrix *m2 = new CBMatrix();
	for(int i=0; i<3; i++)
		for(int j=0; j<3; j++)
			m2->Matrix[i][j]=Matrix[j][i];
	*this = *m2;
	delete m2;
	return *this;
}

CBMatrix& CBMatrix::Inverted(){
	//CBMatrix *m=new CBMatrix();
	/* Deretminant == 1 !!!
	m->Matrix[0][0]=Matrix[1][1]*Matrix[2][2]-Matrix[2][1]*Matrix[1][2];	m->Matrix[1][0]=Matrix[2][0]*Matrix[1][2]-Matrix[1][0]*Matrix[2][2];	m->Matrix[2][0]=Matrix[1][0]*Matrix[2][1]-Matrix[2][0]*Matrix[1][1];
	m->Matrix[0][1]=Matrix[2][1]*Matrix[0][2]-Matrix[0][1]*Matrix[2][2];	m->Matrix[1][1]=Matrix[0][0]*Matrix[2][2]-Matrix[2][0]*Matrix[0][2];	m->Matrix[2][1]=Matrix[2][0]*Matrix[0][1]-Matrix[0][0]*Matrix[2][1];
	m->Matrix[0][2]=Matrix[0][1]*Matrix[1][2]-Matrix[1][1]*Matrix[0][2];	m->Matrix[1][2]=Matrix[1][0]*Matrix[0][2]-Matrix[0][0]*Matrix[1][2];	m->Matrix[2][2]=Matrix[0][0]*Matrix[1][1]-Matrix[1][0]*Matrix[0][1];
	*/
	//*m = *this;
	Inverted();
	return *this;
}

void CBMatrix::Print(){
	printf("%f  %f  %f\n%f  %f  %f\n%f  %f  %f\n\n\n",	Matrix[0][0], Matrix[0][1], Matrix[0][2], Matrix[1][0], Matrix[1][1], Matrix[1][2], Matrix[2][0], Matrix[2][1], Matrix[2][2]);
}