#include "test.h"

Test::Test(int i=5):c(i){};

int Test::i(){
	return c;
}

int main(){

union hack{
	int *i;
	Test *t;
}h;

	Test *t=new Test();
	h.t=t;
	cout <<t->i()<< endl << "adress of t " << h.t << endl;
	*h.i+=1;
	cout << "after hacking : " << t->i() << endl;
	return 0;
}
