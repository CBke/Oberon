#include <iostream>
#ifndef DEF_TEST
#define DEF_TEST
class Test{
	public :
		Test(int);
		int i();
	private :
		int c;
};
#endif
